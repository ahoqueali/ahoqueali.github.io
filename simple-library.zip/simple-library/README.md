== How to run the simple library system api tests ==

Execute the following command:

	./gradlew clean build test  
