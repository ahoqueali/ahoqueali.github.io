package de.berenberg.library;

public interface CD {

}
