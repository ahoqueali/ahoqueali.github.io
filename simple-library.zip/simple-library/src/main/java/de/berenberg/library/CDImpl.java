package de.berenberg.library;

public class CDImpl extends AbstractTitleItem implements CD{

	public CDImpl(String id) {
		super(id);
	}

}
