package de.berenberg.library;

public interface Book {

}
