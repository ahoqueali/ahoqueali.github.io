package de.berenberg.library;

public class BookImpl extends AbstractTitleItem implements Book {

	public BookImpl(String id) {
		super(id);
	}

}
