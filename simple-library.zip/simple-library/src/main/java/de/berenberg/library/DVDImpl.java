package de.berenberg.library;

public class DVDImpl extends AbstractTitleItem implements DVD{

	public DVDImpl(String id) {
		super(id);
	}

}
