package de.berenberg.library;

public class NoSuchMemberException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoSuchMemberException(String message) {
		super(message);
	}
	
	
}
