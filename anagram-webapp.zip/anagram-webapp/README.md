# How to build and run the client server webapp #

## Build ##
1. Unzip folder anagram-webapp.zip
2. cd into anagram-webapp 
3. run ./gradlew clean build

## Run webapp ##
1. From folder anagram-console execute command java -jar build/libs/anagram-webapp-0.1.jar
2. Vist url http://localhost:8080/anagram
3. Enter word abse and press submit 