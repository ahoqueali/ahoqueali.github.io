package com.societegenerale;

import java.io.IOException;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AnagramController {

    @Autowired
    private Dictionary dictionary;

    @PostConstruct
    public void init() throws IOException {
	dictionary.loadWords();
    }

    @GetMapping("/anagram")
    public String anagramForm(@RequestParam(name = "word", required = false, defaultValue = "") String word,
	    Model model) {

	Optional<Set<String>> optional = Optional.ofNullable(dictionary.getAnagrams(word));
	model.addAttribute("word", word);
	if (optional.isPresent()) {
	    Set<String> words = optional.get();
	    model.addAttribute("words", words.stream().collect(Collectors.joining(", ")));
	} else {
	    model.addAttribute("words", "");
	}

	return "result";
    }
}
