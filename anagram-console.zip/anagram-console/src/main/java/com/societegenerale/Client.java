package com.societegenerale;

import java.io.IOException;
import java.util.Optional;
import java.util.Scanner;
import java.util.Set;

public class Client {

    public static void main(String args[]) throws IOException {

	Dictionary dictionary = new AnagramDictionary();
	dictionary.loadWords();

	try (Scanner scanner = new Scanner(System.in)) {
	    String word = "";

	    while (!word.equals("exit")) {
		System.out.println("Enter word: ");
		word = scanner.nextLine();

		Optional<Set<String>> optional = Optional.ofNullable(dictionary.get(word));
		if (optional.isPresent()) {
		    System.out.println("Anagram words:");
		    System.out.println(optional.get());
		} else {
		    System.out.println("No anagram words for " + word);
		}
	    }

	    System.out.println("bye!");

	} catch (Exception e) {
	    e.printStackTrace(System.err);
	}

    }
}
