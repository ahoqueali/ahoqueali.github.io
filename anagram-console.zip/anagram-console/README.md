# How to build and run shell client #

## Build ##
1. Unzip folder anagram-console.zip
2. cd into anagram-console 
3. run ./gradlew clean build

## Run client ##
1. From folder anagram-program execute java -jar build/libs/anagram-console-1.0.jar 