# How to build and run the interaction webapp #

## Build ##
1. Unzip folder anagram-interaction.zip
2. cd into anagram-interaction 
3. run ./gradlew clean build

## Run webapp ##
1. From folder anagram-interaction execute command java -jar build/libs/anagram-interaction-0.1.jar
2. Vist url http://localhost:8080/anagram
3. Enter word abse and press submit 