package com.societegenerale;

import java.io.IOException;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AnagramController {

    @Autowired
    private Dictionary dictionary;

    @PostConstruct
    public void init() throws IOException {
	dictionary.loadWords();
    }

    @GetMapping("/anagram")
    public String anagramForm() {
	return "result";
    }

    @PostMapping("/anagram")
    public String anagramSubmit(@RequestParam(name = "word", required = true, defaultValue = "") String word,
	    @RequestParam(name = "action", required = true, defaultValue = "print") String action, Model model) {

	model.addAttribute("word", word);
	model.addAttribute("words", "");
	model.addAttribute("message", "");

	switch (action) {
	case "print":

	    Optional<Set<String>> optional = Optional.ofNullable(dictionary.get(word));
	    if (optional.isPresent()) {
		Set<String> words = optional.get();
		model.addAttribute("words", words.stream().collect(Collectors.joining(", ")));
	    } else {
		model.addAttribute("message", "No anagram words in dictionary for word " + word);
	    }

	    break;

	case "delete":

	    dictionary.remove(word);
	    model.addAttribute("message", "Word " + word + " removed from dictionary");
	    break;

	case "add":

	    dictionary.add(word);
	    model.addAttribute("message", "Word " + word + " added to dictionary");
	    break;
	}

	return "result";
    }

}
