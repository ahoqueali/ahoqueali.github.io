package com.societegenerale;

import java.io.IOException;
import java.util.Set;

public interface Dictionary {

    public int size();

    public void add(String word);

    public Set<String> get(String word);

    public void loadWords() throws IOException;

    public void remove(String word);
}
