package com.societegenerale;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

@Service
public class AnagramDictionaryService implements Dictionary {

    private Map<String, Set<String>> mapToAnagramWordSet = new ConcurrentHashMap<>();

    @Override
    public void add(final String word) {
	// 1. sort word alphabetically
	String key = getKey(word);
	// 2. check if sorted word exists in map
	if (!mapToAnagramWordSet.containsKey(key)) {
	    // 2.1 if not then add sorted word as key and value into word set
	    Set<String> words = new HashSet<>();
	    words.add(word);
	    mapToAnagramWordSet.put(key, words);
	} else {
	    // 2.2 if exist then add word to word set
	    Set<String> words = mapToAnagramWordSet.get(key);
	    words.add(word);
	}
    }

    @Override
    public Set<String> get(String word) {
	String key = getKey(word);
	return mapToAnagramWordSet.get(key);
    }

    @Override
    public int size() {
	return mapToAnagramWordSet.size();
    }

    private String getKey(final String word) {
	char[] charArray = word.toCharArray();
	Arrays.sort(charArray);
	return new String(charArray);
    }

    @Override
    public void loadWords() throws IOException {

	ClassPathResource classPathResource = new ClassPathResource("words.txt");
	InputStream inputStream = classPathResource.getInputStream();
	try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
	    String word;
	    while ((word = br.readLine()) != null) {
		add(word);
	    }
	}
    }

    @Override
    public void remove(String word) {
	String key = getKey(word);
	mapToAnagramWordSet.remove(key);
    }
}
