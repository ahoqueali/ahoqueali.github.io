package com.societegenerale;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

public class DictionaryTest {

    private Dictionary dictionary;

    @Before
    public void setup() {
	dictionary = new AnagramDictionaryService();
    }

    @Test
    public void givenAnEmptyDictionary_whenGetSize_thenTheDictionaryShouldReturnZero() {
	assertEquals(0, dictionary.size());
    }

    @Test
    public void givenWordOrchestra_whenAddToDictionary_andGetWordOrchestra_thenTheDictionaryShouldReturnWordCarthorse() {
	dictionary.add("carthorse");
	Set<String> expectedSet = new HashSet<>();
	expectedSet.add("carthorse");
	assertEquals(expectedSet, dictionary.get("orchestra"));
    }

    @Test
    public void givenWordTwoTowAndWot_whenAddToDictionary_andGetWordTwoAndTowAndWot_thenTheDictionaryShouldReturnWordsTwoTowAndWot() {
	dictionary.add("two");
	dictionary.add("tow");
	dictionary.add("wot");

	Set<String> expectedSet = new HashSet<>();
	expectedSet.add("wot");
	expectedSet.add("tow");
	expectedSet.add("two");

	assertEquals(expectedSet, dictionary.get("two"));
	assertEquals(expectedSet, dictionary.get("tow"));
	assertEquals(expectedSet, dictionary.get("wot"));
    }

    @Test
    public void givenWordsTextFile_whenLoadToDictionary_thenTheDictionaryShouldBeLoadedWithTheWords()
	    throws IOException {
	dictionary.loadWords();
	assertEquals(433398, dictionary.size());
    }
}
